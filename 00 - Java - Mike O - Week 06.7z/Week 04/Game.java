enum ERROR_CODES {PRINTER_ERROR, DISK_ERROR, NETWORK_ERROR};



enum GAME_STATUS {GAME_OVER, IN_PROGRESS, HUMAN_WINS, DRAW};
/*
{
	public GAME_STATUS ()
	{
	}

	// Acessor


	// Mutator

}

*/

public class Game
{
	//int gameStatus = 0;

	GAME_STATUS gamesStatus = GAME_STATUS.GAME_OVER;


	//Customer mike = new Customer ();


	gamesStatus = GAME_STATUS.HUMAN_WINS;


	if (gameStatus == 1) // In Progress   BAD


 
	if (gamesStatus == GAME_STATUS.IN_PROGRESS)
	{
		klajklajdl
	}

}