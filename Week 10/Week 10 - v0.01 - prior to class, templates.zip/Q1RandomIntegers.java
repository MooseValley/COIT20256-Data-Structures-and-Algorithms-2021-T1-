/*
1. Implement the program designed as part of Activity One in Lecture. The question is repeated here.
Write a java program to generate twenty five random integers between 0 and 100 (inclusive), display the values, display the sorted values, sum and average of the values. Display the list of values greater than 50. Use Lambdas.

*/
import java.security.SecureRandom;

public class Q1RandomIntegers
{
   public static void main (String[] args)
   {
   }
}
