/*
5. Write a java program to:
a) Display the original string values in the array
b) Display the string values converted to uppercase
c) Display the string values in ascending order after filtering the values starting with g or less
d) Display the string values in ascending order after filtering the values starting with g or less.
Data: String [] names = {�bob�, �Mary� �Andrew�, �Tomy�, �Michael�, �Kathy�, �lily�, �Frances�}

*/
public class Q5StringsProcessing
{
   public static void main (String[] args)
   {
   }
}