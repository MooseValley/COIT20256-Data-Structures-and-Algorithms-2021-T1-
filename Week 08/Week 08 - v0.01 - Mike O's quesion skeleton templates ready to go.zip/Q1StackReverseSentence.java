/*
 Author:  Mike O'Malley
   Date:  04-May-2021
Descrtn:  Week 8 Tutorial questions - stacks, queues, trees, BinaryTrees, etc.


1. (Printing a Sentence in Reverse Using a Stack) Write a program that inputs a line of text and uses a stack to display the words of the line in reverse order.  Use java.util.Stack.

Mike O's extras / homework for students to do:
*

*/
public class Q1StackReverseSentence
{
   public static void main (String[] args)
   {

   }
}

