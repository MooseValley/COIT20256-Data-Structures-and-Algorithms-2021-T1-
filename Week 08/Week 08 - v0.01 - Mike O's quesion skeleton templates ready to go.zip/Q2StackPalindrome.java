/*
 Author:  Mike O'Malley
   Date:  04-May-2021
Descrtn:  Week 8 Tutorial questions - stacks, queues, trees, BinaryTrees, etc.

Q2StackPalindrome
2. (Palindrome Tester) Write a program that uses a stack to determine whether a string is a palindrome (i.e., the string is spelled identically backward and forward). The program should ignore space and punctuation. Use java.util.Stack.

Mike O's extras / homework for students to do:
*

*/
public class Q2StackPalindrome
{
   public static void main (String[] args)
   {

   }
}
